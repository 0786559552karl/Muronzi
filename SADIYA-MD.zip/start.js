/**
══════════════════════════════════════════════════════════════════════════════════════════════════════

░██████╗░█████╗░██████╗░██╗██╗░░░██╗░█████╗░░░░░░███╗░░░███╗██████╗░ 
██╔════╝██╔══██╗██╔══██╗██║╚██╗░██╔╝██╔══██╗░░░░░████╗░████║██╔══██╗ 
╚█████╗░███████║██║░░██║██║░╚████╔╝░███████║░░░░░██╔████╔██║██║░░██║ 
░╚═══██╗██╔══██║██║░░██║██║░░╚██╔╝░░██╔══██║░░░░░██║╚██╔╝██║██║░░██║ 
██████╔╝██║░░██║██████╔╝██║░░░██║░░░██║░░██║░░░░░██║░╚═╝░██║██████╔╝ 
╚═════╝░╚═╝░░╚═╝╚═════╝░╚═╝░░░╚═╝░░░╚═╝░░╚═╝░░░░░╚═╝░░░░░╚═╝╚═════╝░ 

══════════════════════════════════════════════════════════════════════════════════════════════════════
*
   * @project_name : SADIYA-MD
   * @creator : Sadiya Tech
   * @youtube : https://www.youtube.com/@Sadiya-Tech
   * @description : SADIYA-MD ,Javascript WhatsApp Bot Made By Sadiya Tech.
*
* 
   * Created By Sadiya Tech.
   * © 2025 SADIYA-MD .
*/

function _0x57ac(){const _0x137dd0=['533762WCiekZ','temp.zip','downloadBuffer','unlinkSync','megajs','/index.js','❌\x20Error\x20during\x20download\x20and\x20extraction:','5113233DdyNUl','https://raw.githubusercontent.com/tech14555/db','mega_zip','get','151345XntnZn','exit','axios','2261200mXWnnh','adm-zip','writeFileSync','./index.js','message','fromURL','⭕\x20Main\x20downloaded\x20successfully\x20✅','762kEgCnm','data','⏩\x20Skip\x20download\x20main\x20file','/lib','join','11207DublHS','980izACyr','3688cKhGcF','log','952641GjdPxU','error','extractAllTo','path','An\x20error\x20occurred:'];_0x57ac=function(){return _0x137dd0;};return _0x57ac();}const _0x159d6d=_0x3614;function _0x3614(_0x3ae4c8,_0x124ab2){const _0x57acf5=_0x57ac();return _0x3614=function(_0x361480,_0x17cf16){_0x361480=_0x361480-0x18d;let _0x22b4a2=_0x57acf5[_0x361480];return _0x22b4a2;},_0x3614(_0x3ae4c8,_0x124ab2);}(function(_0x3adc23,_0x327b81){const _0x453537=_0x3614,_0x37e39b=_0x3adc23();while(!![]){try{const _0xac2837=-parseInt(_0x453537(0x1a3))/0x1+parseInt(_0x453537(0x198))/0x2+parseInt(_0x453537(0x193))/0x3+parseInt(_0x453537(0x191))/0x4*(-parseInt(_0x453537(0x190))/0x5)+-parseInt(_0x453537(0x1ad))/0x6*(-parseInt(_0x453537(0x18f))/0x7)+parseInt(_0x453537(0x1a6))/0x8+-parseInt(_0x453537(0x19f))/0x9;if(_0xac2837===_0x327b81)break;else _0x37e39b['push'](_0x37e39b['shift']());}catch(_0x157a1b){_0x37e39b['push'](_0x37e39b['shift']());}}}(_0x57ac,0x298e3));const fs=require('fs'),path=require(_0x159d6d(0x196)),{File}=require(_0x159d6d(0x19c)),AdmZip=require(_0x159d6d(0x1a7)),axios=require(_0x159d6d(0x1a5)),db_repo=_0x159d6d(0x1a0),ZIP_DIR='./';async function downloadAndExtractZip(){const _0x3bb538=_0x159d6d;try{const _0x3c1b97=await axios[_0x3bb538(0x1a2)](db_repo+'/refs/heads/main/mega_zip.json'),_0x1e8071=_0x3c1b97[_0x3bb538(0x1ae)][_0x3bb538(0x1a1)],_0x3001da=File[_0x3bb538(0x1ab)](_0x1e8071),_0x3e531e=await _0x3001da[_0x3bb538(0x19a)](),_0x3c5e5a=path[_0x3bb538(0x18e)](__dirname,_0x3bb538(0x199));fs[_0x3bb538(0x1a8)](_0x3c5e5a,_0x3e531e);const _0x1d7713=new AdmZip(_0x3c5e5a);_0x1d7713[_0x3bb538(0x195)](ZIP_DIR,!![]),fs[_0x3bb538(0x19b)](_0x3c5e5a),console['log'](_0x3bb538(0x1ac));}catch(_0x2676a6){console['error'](_0x3bb538(0x19e),_0x2676a6[_0x3bb538(0x1aa)]),process[_0x3bb538(0x1a4)](0x1);}}const main=async()=>{const _0x3ec901=_0x159d6d;try{!fs['existsSync'](__dirname+_0x3ec901(0x18d)||'/plugins'||_0x3ec901(0x19d))?await downloadAndExtractZip():console[_0x3ec901(0x192)](_0x3ec901(0x1af)),require(_0x3ec901(0x1a9));}catch(_0x22141c){console[_0x3ec901(0x194)](_0x3ec901(0x197),_0x22141c[_0x3ec901(0x1aa)]);}};main();
